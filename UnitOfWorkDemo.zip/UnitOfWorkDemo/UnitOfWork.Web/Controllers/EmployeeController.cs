﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using UnitOfWork.Services.Emoployee_Service;
using UnitOfWorkDemo.Data;

namespace UnitOfWork.Web.Controllers
{
    public class EmployeeController : Controller
    {
        private readonly IEmployeeService _employeeService;
        public EmployeeController(IEmployeeService employeeService)
        {
            _employeeService = employeeService;
        }
        public IActionResult Index()
        {
            return View();
        }
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(Employee employee)
        {
                
            Employee obj =  _employeeService.GetDubLicateEmp(employee.Name, employee.Mobile);
            if (obj == null)
            {
                _employeeService.InsertEmployee(employee);
                var JsonResult = new
                {
                    msg = "Added",
                    name = employee.Name.Trim()
                };
                return Json(JsonResult);
            }
            else
            {
                var JsonResult = new
                {
                    msg = "Null",
                    name = obj.Name.Trim()
                };
                return Json(JsonResult);

            }

        }

        public IActionResult Edit(int ID)
        {
            Employee employee = _employeeService.GetEmployeeByID(ID);
            return View(employee);
        }
        [HttpPost]
        public IActionResult Edit(Employee employee)
        {
            Employee data = _employeeService.GetEmployeeByID(employee.ID);
            if (data != null)
            {

                data.Name = employee.Name;
                data.Mobile = employee.Mobile;
                data.Designation = employee.Designation;
                _employeeService.Update(data);
                
            }
            return RedirectToAction("Index");
        }

        public JsonResult DeleteCustomer(int ID)
        {
            string name;
            try
            {

                Employee employee = _employeeService.GetEmployeeByID(ID);
                name = employee.Name;
                _employeeService.Delete(ID);
                
            }
            catch (Exception ex)
            {

                throw ex;
            }
            var JsonResult = new
            {
                msg = "Deleted",
                Name = name.Trim()
            };
            return Json(JsonResult);
        }

        public ActionResult LoadData()
        {
            try
            {
                //Creating instance of DatabaseContext class  
                var draw = Request.Form["draw"].FirstOrDefault();
                var start = Request.Form["start"].FirstOrDefault();
                var length = Request.Form[("length")].FirstOrDefault();
                var sortColumn = Request.Form["columns"] + Request.Form["order[0][column]"].FirstOrDefault() + "][name]".FirstOrDefault();
                var sortColumnDir = Request.Form["order[0][dir]"].FirstOrDefault();
                var searchValue = Request.Form["search[value]"].FirstOrDefault();

                //Paging Size (10,20,50,100)    
                int pageSize = length != null ? Convert.ToInt32(length) : 0;
                int skip = start != null ? Convert.ToInt32(start) : 0;
                int recordsTotal = 0;

                // Getting all Customer data    
                IList<Employee> customerData = _employeeService.GetEmployeeList();


                if (!string.IsNullOrEmpty(searchValue))
                {
                    customerData = customerData.Where(P => ((P.Name != null && P.Name.ToLower().Contains(searchValue.ToLower())) ||
                                                             (P.Mobile != null && P.Mobile.Contains(searchValue)) ||
                                                             (P.Designation != null && P.Designation.Contains(searchValue)) ||
                                                             (P.ID != 0 && P.ID.Equals(searchValue)))
                                                             ).ToList();
                }

                //total number of rows count     
                recordsTotal = customerData.Count();
                //Paging     
                var data = customerData.Skip(skip).Take(pageSize).ToList();
                //Returning Json Data    
                return Json(new { draw = draw, recordsFiltered = recordsTotal, recordsTotal = recordsTotal, data = data });

            }
            catch (Exception)
            {
                throw;
            }

        }
    }
}