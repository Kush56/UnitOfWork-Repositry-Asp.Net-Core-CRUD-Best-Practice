﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using UnitOfWork.Services.Emoployee_Service;
using UnitOfWorkDemo.Data;

namespace UnitOfWork.Services.Emoployee_Service
{
    
    public class EmployeeService : IEmployeeService
    {
        private readonly ITenantUnitOfWork _unitOfWork;
        public EmployeeService(ITenantUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;

        }
        public void Delete(int ID)
        {
            try
            {
                Employee employee = _unitOfWork.GetRepository<Employee>().GetSingle(l => l.ID == ID);
                _unitOfWork.GetRepository<Employee>().Delete(employee);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public Employee GetByID(int ID)
        {
            try
            {
                Employee employee =  _unitOfWork.GetRepository<Employee>().GetSingle(l => l.ID == ID);
                return employee;
            }
            catch (Exception x)
            {

                throw x;
            }
        }

        public Employee GetDubLicateEmp(string name, string mobile)
        {
            try
            {
                Employee employee = _unitOfWork.GetRepository<Employee>().GetSingle(l => l.Name == name && l.Mobile == mobile);
                return employee;
            }
            catch (Exception ex)
            {

                throw ex;
            }
            
        }

        public Employee GetEmployeeByID(int ID)
        {
            try
            {
                Employee employee = _unitOfWork.GetRepository<Employee>().GetSingle(l => l.ID == ID);
                return employee;
            }
            catch (Exception)
            {

                throw;
            }
        }

        public IList<Employee> GetEmployeeList()
        {
            try
            {
                var repository = _unitOfWork.GetRepository<Employee>();
                IList<Employee> employee = repository.Query().Where(x=>x.IsDelete==false).OrderBy(x => x.Name).ToList();
                return employee;
            }
            catch (Exception ex)
            {

                throw ex; 
            }
           
        }

        public  void InsertEmployee(Employee employee)
        {
            try
            {
                 _unitOfWork.GetRepository<Employee>().Add(employee);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public void Update(Employee data)
        {
            try
            {
                _unitOfWork.GetRepository<Employee>().Update(data);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
    }
}
