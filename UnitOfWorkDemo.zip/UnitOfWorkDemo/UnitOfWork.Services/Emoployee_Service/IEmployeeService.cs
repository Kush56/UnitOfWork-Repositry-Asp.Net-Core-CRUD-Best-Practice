﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using UnitOfWorkDemo.Data;

namespace UnitOfWork.Services.Emoployee_Service
{
    public interface IEmployeeService
    {
        Employee GetByID(int ID);
        Employee GetEmployeeByID(int ID);
        void Update(Employee data);
        void InsertEmployee(Employee employee);
        Employee GetDubLicateEmp(string name, string mobile);
        IList<Employee> GetEmployeeList();
        void Delete(int iD);
    }
}
