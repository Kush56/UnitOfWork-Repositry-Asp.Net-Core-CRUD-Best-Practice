﻿using System;
using UnitOfWorkDemo.Data;

namespace UnitOfWorkDemo.Services
{
    public class EmployeeService : IEmployeeService
    {
        private readonly ITenantUnitOfWork _unitOfWork;
        public EmployeeService(ITenantUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;

        }
        public Employee GetByID(int ID)
        {
            try
            {
                Employee employee = _unitOfWork.GetRepository<Employee>().GetSingle(l=>l.ID==ID);
                return employee;
            }
            catch (Exception x)
            {

                throw x;
            }
        }
    }
}
