﻿using System;
using System.Collections.Generic;
using System.Text;
using UnitOfWorkDemo.Data;

namespace UnitOfWorkDemo.Services
{
    public interface IEmployeeService
    {
        Employee GetByID(int ID);
    }
}
