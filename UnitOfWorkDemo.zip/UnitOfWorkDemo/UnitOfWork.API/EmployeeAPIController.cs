﻿using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using UnitOfWork;
using UnitOfWork.Services.Emoployee_Service;
using UnitOfWorkDemo.Data;

namespace UnitOfWork.API.Controller
{
    [ApiController]
    [Route("api/[Controller]")]
    public class EmployeeAPIController : ControllerBase
    {
        private readonly IEmployeeService _employeeService;
        public EmployeeAPIController(IEmployeeService employeeService)
        {
            _employeeService = employeeService;
        }

        [AllowAnonymous]
        [HttpGet("GetBy/{id}")]
        public IActionResult Edit(int ID)
        {
            Employee employee = _employeeService.GetEmployeeByID(ID);
            return Ok(employee);
        }

        [AllowAnonymous]
        [HttpGet("GetAll")]
        public IActionResult GetAllList()
        {
            IList<Employee> customerData = _employeeService.GetEmployeeList();
            return Ok(customerData);
        }

        [HttpGet("DeleteBy/{id}")]
        public IActionResult Delete(int ID)
        {
            string name;
            try
            {

                Employee employee = _employeeService.GetEmployeeByID(ID);
                name = employee.Name;
                _employeeService.Delete(ID);

            }
            catch (Exception ex)
            {

                throw ex;
            }
            var JsonResult = new
            {
                message = "Success",
                data = name
            };
            return Ok(JsonResult);
        }
    }
}
