﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace UnitOfWorkDemo.Data
{
    public class AspNetUserLogins : BaseEntity
    {
        public virtual string LoginProvider { get; set; }

        public virtual string ProviderKey { get; set; }

        public virtual string ProviderDisplayName { get; set; }

        [ForeignKey("UserId")]
        public AspNetUsers aspNetUsers { get; set; }
        public virtual int UserId { get; set; }

    }
}
