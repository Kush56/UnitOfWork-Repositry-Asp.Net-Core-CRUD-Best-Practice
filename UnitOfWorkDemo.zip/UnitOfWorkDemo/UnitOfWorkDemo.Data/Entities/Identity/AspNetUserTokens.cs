﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace UnitOfWorkDemo.Data
{
    public class AspNetUserTokens : BaseEntity
    {
        
        [ForeignKey("UserId")]
        public AspNetUsers aspNetUsers { get; set; }
        public virtual int UserId { get; set; }
        public virtual string LoginProvider { get; set; }
        public virtual string Name { get; set; }
        public virtual string Value { get; set; }
    }
}
