﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace UnitOfWorkDemo.Data
{
    public class AspNetUserClaims 
    {
        [Key]
        public  virtual int Id { get; set; }

        [ForeignKey("UserId")]
        public AspNetUsers aspNetUsers { get; set; }
        [Display(Name = "User Name")]
        public virtual int UserId { get; set; }
        public virtual string ClaimType { get; set; }
        public virtual string ClaimValue { get; set; }

    }
}
