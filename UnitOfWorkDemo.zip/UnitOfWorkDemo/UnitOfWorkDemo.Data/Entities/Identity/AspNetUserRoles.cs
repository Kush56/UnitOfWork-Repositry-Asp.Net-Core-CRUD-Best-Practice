﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace UnitOfWorkDemo.Data
{
    public class AspNetUserRoles
    {
        public virtual int UserId { get; set; }
        [ForeignKey("Id")]
        [Display(Name = "User Name")]
        public virtual AspNetRoles AspNetRoles { get; set; }
        public virtual int RoleId { get; set; }
    }
}
