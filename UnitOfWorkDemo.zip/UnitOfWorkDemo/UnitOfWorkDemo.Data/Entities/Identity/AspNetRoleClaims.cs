﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace UnitOfWorkDemo.Data
{
    public class AspNetRoleClaims :  BaseEntity
    {

        [ForeignKey("RoleId")]
        public AspNetRoles AspNetRoles { get; set; }

        [Display(Name = "User Role")]
        public virtual int RoleId { get; set; }

        public virtual string ClaimType { get; set; }

        public virtual string ClaimValue { get; set; }
         
    }
}
