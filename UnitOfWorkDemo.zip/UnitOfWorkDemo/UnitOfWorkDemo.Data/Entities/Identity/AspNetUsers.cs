﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UnitOfWorkDemo.Data
{
    public class AspNetUsers : BaseEntity
    {
        public virtual string UserName { get; set; }
        public virtual string NormalizedUserName { get; set; }

        public virtual string Email { get; set; }

        public virtual string NormalizedEmail { get; set; }

        public virtual string EmailConfirmed { get; set; }

        public virtual byte[] PasswordHash { get; set; }

        public virtual string SecurityStamp { get; set; }

        public virtual string ConcurrencyStamp { get; set; }

        public virtual string PhoneNumber { get; set; }

        public virtual string PhoneNumberConfirmed { get; set; }

        public virtual string TwoFactorEnabled { get; set; }

        public virtual int LockoutEnd { get; set; }

        public virtual byte LockoutEnabled { get; set; }

        public virtual string AccessFailedCount { get; set; }
    }
}
