﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace UnitOfWorkDemo.Data
{
    
    public class Employee: BaseEntity
    {
        [MaxLength(50)]
        [Display(Name="Employee Name")]
        public virtual string Name { get; set; }
        [MaxLength(10)]
        [Display(Name = "Contact Number")]
        public virtual string Mobile { get; set; }
        public virtual string Address { get; set; }
        public virtual string Designation { get; set; }
    }
}
