﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace UnitOfWorkDemo.Data
{
    public class BaseEntity
    {
        [Key]
        public int ID { get; set; }
        [Display(Name ="Status")]
        public bool IsDelete { get; set; }
        public int? CreatedBy { get; set; }
        [DataType(DataType.Date)]
        public DateTime? CreatedOn { get; set; }
        public int? UpdatedBy { get; set; }
        [DataType(DataType.Date)]
        public DateTime? UpdatedOn { get; set; }

        public BaseEntity()
        {

            IsDelete = false;
            CreatedOn = DateTime.Now;
            UpdatedOn = DateTime.Now;
        }
    }
    
}
