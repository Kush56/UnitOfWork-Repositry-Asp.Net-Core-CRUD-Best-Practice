﻿using System.Threading.Tasks;

namespace UnitOfWorkDemo.Data
{
    public interface ITenantUnitOfWork
    {
        void Save();
        Task SaveAsync();
        /// <summary>
        /// Gets the repository.
        /// </summary>
        /// <typeparam name="T">The type of the entity.</typeparam>
        /// <returns>Repository</returns>
        IRepository<T> GetRepository<T>()
        where T : class;
    }
}