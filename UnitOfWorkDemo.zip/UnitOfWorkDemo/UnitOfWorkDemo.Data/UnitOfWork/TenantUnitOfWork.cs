﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace UnitOfWorkDemo.Data
{
    public class TenantUnitOfWork : ITenantUnitOfWork ,IDisposable
    {

        private readonly TenantDbContext _context;
        //#Kush Repository

        /// <summary>
        /// The repositories
        /// </summary>
        private Dictionary<Type, object> repositories;

        public TenantUnitOfWork(TenantDbContext context)
        {
            _context = context;
        }

        private bool disposed = false;

        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    _context.Dispose();
                }
            }
            this.disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Gets the repository.
        /// </summary>
        /// <typeparam name="TEntity">The type of the entity.</typeparam>
        /// <returns></returns>
        public IRepository<T> GetRepository<T>()
            where T : class
        {
            if (this.repositories == null)
            {
                this.repositories = new Dictionary<Type, object>();
            }

            var type = typeof(T);
            if (!this.repositories.ContainsKey(type))
            {
                this.repositories[type] = new Repository<T>(this._context);
            }

            return (IRepository<T>)this.repositories[type];
        }

        public void Save()
        {
            _context.SaveChanges();
        }

        public async Task SaveAsync()
        {
            await _context.SaveChangesAsync();
        }

        
    }
}
